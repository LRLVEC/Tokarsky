#version 450 core
in vec4 fragColor;
out vec4 Color;
void main()
{
	Color = fragColor;
}